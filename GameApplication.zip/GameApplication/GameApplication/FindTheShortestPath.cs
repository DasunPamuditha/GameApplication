﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GameApplication
{
    public partial class FindTheShortestPath : Form
    {
        private string connectionString = "Data Source=DESKTOP-4L3N13Q;Initial Catalog=GameApplication;Integrated Security=True"; 
        private int[,] cityDistances = new int[9, 9];
        private int selectedCityIndex;
        private int shortestPath;
        public FindTheShortestPath()
        {
            InitializeComponent();
        }

        private void FindTheShortestPath_Load(object sender, EventArgs e)
        {
            GenerateCityDistances();
            SelectRandomCity();
            DisplayCityDistances();
            LoadTableData();

            string selectedCity = ((char)('A' + selectedCityIndex)).ToString();
            MessageBox.Show($"The system has randomly selected City is {selectedCity}.");
        }
        private void ClearGameData()
        {
            txt_shortestpath.Clear();
            txt_name.Clear();
            
        }
        private void GenerateCityDistances()
        {
            Random random = new Random();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand clearTableCommand = new SqlCommand("TRUNCATE TABLE Distance", connection);
                    clearTableCommand.ExecuteNonQuery();

                    SqlCommand insertCommand = new SqlCommand("INSERT INTO Distance (City1, City2, Distance) VALUES (@City1, @City2, @Distance)", connection);

                    for (int i = 0; i < 9; i++)
                    {
                        for (int j = i + 1; j < 9; j++)
                        {
                            int distance = random.Next(5, 51); 
                            cityDistances[i, j] = distance;
                            cityDistances[j, i] = distance;

                            insertCommand.Parameters.Clear();
                            insertCommand.Parameters.AddWithValue("@City1", i);
                            insertCommand.Parameters.AddWithValue("@City2", j);
                            insertCommand.Parameters.AddWithValue("@Distance", distance);
                            insertCommand.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while generating city distances: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        private void LoadTableData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-4L3N13Q;Initial Catalog=GameApplication;Integrated Security=True"))
                {
                    connection.Open();

                    string selectQuery = "SELECT * FROM Distance";
                    using (SqlCommand command = new SqlCommand(selectQuery, connection))
                    {
                        SqlDataReader reader = command.ExecuteReader();

                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        dataGridView1.DataSource = dataTable;
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading table data: " + ex.Message);
            }
        }

        private void SelectRandomCity()
        {
            Random random = new Random();
            selectedCityIndex = random.Next(0, 9); 
        }

        private void DisplayCityDistances()
        {
            for (int i = 0; i < 9; i++)
            {
                if (i != selectedCityIndex)
                {
                    string city = ((char)('A' + i)).ToString();
                    int distance = cityDistances[selectedCityIndex, i];
                    txt_shortestpath.AppendText($"Distance from City {city} to the selected city: {distance} km\r\n");
                }
            }
        }
        private void btn_submit_Click(object sender, EventArgs e)
        {
            string PlayerName = txt_name.Text;
            string PlayerAnswer = txt_shortestpath.Text;

            if (ValidatePlayerAnswer(PlayerAnswer))
            {
                if (int.Parse(PlayerAnswer) == shortestPath)
                {
                    SavePlayerData(PlayerName, PlayerAnswer, shortestPath);
                    MessageBox.Show("Congratulations! Your answer is correct.");
                }
                else
                {
                    MessageBox.Show("Sorry, your answer is incorrect.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric answer.");
            }
        }
        private bool ValidatePlayerAnswer(string PlayerAnswer)
        {
            int answer;
            return int.TryParse(PlayerAnswer, out answer);
        }
        private void SavePlayerData(string PlayerName, string Answer, int Distance)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-4L3N13Q;Initial Catalog=GameApplication;Integrated Security=True"))
                {
                    connection.Open();

                    string insertQuery = "INSERT INTO PlayerAnswer (PlayerName, Answer, Distance) VALUES (@PlayerName, @Answer, @Distance)";
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@PlayerName", PlayerName);
                        command.Parameters.AddWithValue("@Answer", Answer);
                        command.Parameters.AddWithValue("@Distance", Distance);
                        command.ExecuteNonQuery();
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving player data: " + ex.Message);
            }
        }
        private void btn_calculate_Click(object sender, EventArgs e)
        {
            shortestPath = CalculateShortestPath();
            txt_shortestpath.Text = shortestPath.ToString();
        }

        private int CalculateShortestPath()
        {
            int[] distances = new int[9];
            bool[] visited = new bool[9];
            int startCity = selectedCityIndex;

            // Initialize distances array with maximum values
            for (int i = 0; i < 9; i++)
            {
                distances[i] = int.MaxValue;
            }

            distances[startCity] = 0;

            for (int count = 0; count < 9 - 1; count++)
            {
                int minDistance = FindMinimumDistance(distances, visited);
                visited[minDistance] = true;

                for (int city = 0; city < 9; city++)
                {
                    if (!visited[city] && cityDistances[minDistance, city] != 0 && distances[minDistance] != int.MaxValue
                        && distances[minDistance] + cityDistances[minDistance, city] < distances[city])
                    {
                        distances[city] = distances[minDistance] + cityDistances[minDistance, city];
                    }
                }
            }

            // The shortest path is the distance to the selected city
            return distances[selectedCityIndex];
        }

        private int FindMinimumDistance(int[] distances, bool[] visited)
        {
            int minDistance = int.MaxValue;
            int minDistanceIndex = -1;

            for (int city = 0; city < 9; city++)
            {
                if (!visited[city] && distances[city] <= minDistance)
                {
                    minDistance = distances[city];
                    minDistanceIndex = city;
                }
            }

            return minDistanceIndex;
        }

        private void FindTheShortestPath_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gameApplicationDataSet.Distance' table. You can move, or remove it, as needed.
            this.distanceTableAdapter.Fill(this.gameApplicationDataSet.Distance);
            // TODO: This line of code loads data into the 'gameApplicationDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.gameApplicationDataSet.City);
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-4L3N13Q;Initial Catalog=GameApplication;Integrated Security=True"))
                {
                    connection.Open();

                    string selectQuery = "SELECT * FROM Distance";
                    using (SqlCommand command = new SqlCommand(selectQuery, connection))
                    {
                        SqlDataReader reader = command.ExecuteReader();

                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        dataGridView1.DataSource = dataTable;
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading table data: " + ex.Message);
            }
        }
    }       
}